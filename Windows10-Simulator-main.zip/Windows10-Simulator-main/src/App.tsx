// import React from "react";
import Desktop from "./features/desktop/desktop";
import "./index.css";
function App() {
  return <Desktop />;
}

export default App;
